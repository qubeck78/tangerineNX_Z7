#include "gfAudio.h"


uint32_t gfAudioInit()
{
   if( aud->id != 0x80000007 )
   {
      return 1;
   }

   //stop dma
   //aud->audioDmaConfig  = 0x00;

   return 0;
}

uint32_t gfAudioConfigure( uint32_t samplingRate, uint32_t samplingRateDivisor )
{

   samplingRateDivisor &= 0xff;

   if( samplingRateDivisor == 0 )
   {
      return 1;
   }

   aud->fifoReadConfig = samplingRateDivisor - 1;

   switch( samplingRate )
   {

      case GF_AUDIO_SAMPLING_RATE_48000:

         //i2s freq 48kHz @ 100Mhz base clock ( base freq: 1536000 Hz )
         aud->i2sClockConfig  = 0x00410020;

         break;

      case GF_AUDIO_SAMPLING_RATE_44100:

         //i2s freq 44.1kHz @ 100Mhz base clock ( base freq: 1411200 Hz )
         aud->i2sClockConfig  = 0x00470023;

         break;

      default:

         return 1;
   }

   return 0;
}

uint32_t gfAudioStopDMA()
{
   return 1;
}

uint32_t gfAudioPlayDMA( int16_t *buffer, uint32_t length, uint32_t format, uint32_t flags )
{


   return 1;
}

uint32_t gfAudioPlayFifo( int16_t *buffer, uint32_t numSamples )
{
   uint32_t *bufferL;
   uint32_t  i;

   if( !buffer )
   {
      return 1;
   }


   bufferL = (uint32_t*)buffer;
   numSamples /= 2;

   for( i = 0; i < numSamples; i++ )
   {
      while( aud->audioFiFoStatus & 4 );   //wait if queue full
      aud->audioFiFoData = bufferL[i];

   }

   return 0;
}

