#include "bsp.h"
#include "osAlloc.h"
#include "osFile.h"
#include "gfFont.h"
#include "gfBitmap.h"
#include "gfJPEG.h"
#include "gfDrawing.h"


//#include "sleep.h"
#include <stdint.h>
#include <stddef.h>  // for size_t
#include <unistd.h>  // for STDERR_FILENO

uint32_t    randomSeed = 3242323459;

tgfTextOverlay  con;

_BSP_T 		               	*bsp 			= (_BSP_T *)		0x41000000;
_VGA_T 	                   	*vga	      	= (_VGA_T*)			0x42000000;
_PS2HOST_T 	               	*ps2Host	    = (_PS2HOST_T*)		0x43000000;
_VGA_DMA_T 					*vgadma			= (_VGA_DMA_T*)		0x44000000;
_AUDIO_REGISTERS_T          *aud         = (_AUDIO_REGISTERS_T*)0x45000000;


#ifdef __cplusplus
extern "C" 
#endif
int _write ( int file, const void * ptr, size_t len ) 
{
    char        buf[4];
    uint32_t    i;

    if( ( file == STDOUT_FILENO ) || ( file == STDERR_FILENO ) )
    {

        buf[1] = 0;

        for( i = 0; i < len; i++ )
        {
            buf[0] = ((char*)ptr)[i];
            toPrint( &con, buf );
        }

        return len;
    }
    else
    {
        return 0;
    }
}


uint32_t bspInit()
{
   vga->vmMode       		= _VIDEOMODE_TEXT160_ONLY;

   //connect gfxlib con to hardware text overlay   
   con.type                = GF_TEXT_OVERLAY_TYPE_HARDWARE;
   con.flags               = 0;
   con.width               = 160;               //clear whole buffer
   con.height              = 90;
   con.cursX               = 0;
   con.cursY               = 0;
   con.textAttributes      = 0x0f;
   con.font                = NULL;
   con.textBuffer          = (uint8_t*) 0x40000000;

   toCls( &con );

   con.textAttributes   = 0x8f;
   con.height           = 45;

   //init alloc mechanism, use last 64MB of DDR3 memory
   
   //in ldscript.ld change ddr size to 0x1bf00000
   //to free last 64MB used by dynamic allocation

   osAllocInit();
   osAllocAddNode( 0, ( void* )_SYSTEM_MEMORY_BASE, _SYSTEM_MEMORY_SIZE, OS_ALLOC_MEMF_CHIP );

   randomSeed += getTicks();

   return 0;
}

uint32_t randomNumber()
{
    uint32_t r = randomSeed;

    r ^= r << 13;
    r ^= r >> 17;
    r ^= r << 5;

    randomSeed = r;

    return r;

} 

void hexDigit(char *string,char digit)
{
    digit &= 0x0f;
    
    if( digit<10 )
    {
        string[0] = digit + '0';
        string[1] = 0;
    }
    else
    {
        string[0] = digit + 'a' - 10;
        string[1] = 0;
    }
}

void itoaHex2Digits( uint32_t value, char* str )
{
    hexDigit(&str[0], ( value >> 4 ) & 0x0f );
    hexDigit(&str[1], ( value ) & 0x0f );
}

void itoaHex4Digits( uint32_t value, char* str )
{
    hexDigit(&str[4], ( value >> 12 ) & 0x0f );
    hexDigit(&str[5], ( value >> 8 ) & 0x0f );

    hexDigit(&str[6], ( value >> 4) & 0x0f );
    hexDigit(&str[7], ( value ) & 0x0f );
}


void itoaHex8Digits( uint32_t value, char* str )
{
    hexDigit(&str[0], ( value >> 28 ) & 0x0f );
    hexDigit(&str[1], ( value >> 24 ) & 0x0f );

    hexDigit(&str[2], ( value >> 20 ) & 0x0f );
    hexDigit(&str[3], ( value >> 16 ) & 0x0f );

    hexDigit(&str[4], ( value >> 12 ) & 0x0f );
    hexDigit(&str[5], ( value >> 8 ) & 0x0f );

    hexDigit(&str[6], ( value >> 4) & 0x0f );
    hexDigit(&str[7], ( value ) & 0x0f );
}

uint32_t getTicks()
{
   return bsp->tickTimerCounter;
}

void delayMs( uint32_t delay )
{
    uint32_t startMs;
    
    startMs = bsp->tickTimerCounter;
    
    while( bsp->tickTimerCounter < ( startMs + delay ) );
}

uint32_t setVideoMode( uint32_t videoMode )
{
	uint32_t    i;


	i = ( videoMode >> 2 ) & 3;

	switch( i )
	{
		case 0:

			//80x45

			con.width   = 80;
			con.height  = 45;

			break;

		case 1:

			//160x45

			con.width   = 160;
			con.height  = 45;

			break;

		case 2:
			//160x90

			con.width   = 160;
			con.height  = 90;

			break;

		default:
			return 1;
	}


	i = ( videoMode >> 4 ) & 3;

	switch( i )
	{

		case 0:

			//426x240

			vgadma->ch1DmaRequestLength = 107;     //107 64-bit words
			vgadma->ch1DmaRequestPtrAdd = 0x400;    //row width 1024 bytes, 512 pixels

			break;

		case 1:

			//640x360

			vgadma->ch1DmaRequestLength = 160;		//160 64-bit words
			vgadma->ch1DmaRequestPtrAdd = 0x800;    //row width 2048 bytes, 1024 pixels

			break;

		case 2:

			//1280x720

			vgadma->ch1DmaRequestLength = 320;		//320 64-bit words
			vgadma->ch1DmaRequestPtrAdd = 0x1000;    //row width 4096 bytes, 2048 pixels

			break;

		default:
			return 1;

	}


	vga->vmMode = videoMode;


   return 0;
}

void waitVSync()
{
    do{}while( ! vga->pgVSync );
}

void reboot()
{
	do{}while( 1 );
}
