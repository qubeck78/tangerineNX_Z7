#ifndef _MODPLAYER_H
#define _MODPLAYER_H

#include "gftypes.h"


uint32_t mpInit( void );
uint32_t mpPlay( char *fileName );

#endif
