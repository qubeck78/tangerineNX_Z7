#ifndef _MP3PLAYER_H
#define _MP3PLAYER_H

#include "gftypes.h"


uint32_t mp3Init( void );
uint32_t mp3Play( char *mp3FileName );

#endif
