#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"

#include "bsp.h"
#include "osFile.h"
#include "osAlloc.h"
#include "gfDrawing.h"
#include "gfBitmap.h"
#include "gfFont.h"

extern tgfTextOverlay  	con;

tosDir            		dir;
tosDirItem        		dirItem;

tgfBitmap				screen;
tgfBitmap				bmp;


uint32_t listDir( char *path )
{
	uint32_t rv;


	rv = osDirOpen( &dir, path );

	do
	{
		rv = osDirRead( &dir, &dirItem );

		if( rv )
		{
			break; // Error or end of dir
		}

		printf( "%s\n", dirItem.name );


	}while( 1 );

	osDirClose( &dir );


	return 0;
}

int main()
{
	uint32_t rv;

    init_platform();

    rv = bspInit();

    rv = osFInit();

    con.textAttributes = 0x0f;
    con.flags |= GF_TEXT_OVERLAY_FLAG_SHOW_CURSOR;

    toCls( &con );

    con.textAttributes = 0x8f;

    bsp->frameTimerReset = 1;

    printf( "tangerineNX Z7_20\n\nHardware list:\n" );
    printf( "%08x %08x\n", (int)bsp->id, (int)bsp->version );
    printf( "%08x %08x\n", (int)aud->id, (int)aud->version );
    printf( "%08x %08x\n", (int)ps2Host->id, (int)ps2Host->version );
    printf( "%08x %08x\n", (int)vga->id, (int)vga->version );
    printf( "%08x %08x\n", (int)vgadma->id, (int)vgadma->version );

    printf( "\n" );


    listDir( "0:" );


    /*screen.width	= 426;
    screen.rowWidth	= 512;
    screen.height	= 240;
    */

    /*screen.width	= 640;
	screen.rowWidth	= 1024;
	screen.height	= 360;
	*/

    screen.width	= 1280;
	screen.rowWidth	= 2048;
	screen.height	= 720;

    screen.flags	= 0;


    screen.buffer	= osAlloc( screen.rowWidth * 2 * screen.height, OS_ALLOC_MEMF_CHIP );
    vgadma->ch1DmaPointerStart	= (uint32_t) screen.buffer;

/*
    vgadma->ch1DmaRequestLength	= 107;	//107 64-bit words
    vga->vmMode	= _VIDEOMODE_426_TEXT160_OVER_GFX;
*/

/*
 	vgadma->ch1DmaRequestLength	= 160;	//160 64-bit words
    vga->vmMode	= _VIDEOMODE_640_TEXT160_OVER_GFX;
*/


    vgadma->ch1DmaRequestLength	= 320;	//320 64-bit words
	vga->vmMode	= _VIDEOMODE_1280_TEXT160_OVER_GFX;

    vgadma->ch1DmaRequestPtrAdd	= screen.rowWidth * 2;


    gfFillRect( &screen, 0, 0, screen.width - 1, screen.height - 1, 0x0 );

    gfLoadBitmapFS( &bmp, "0:las.gbm" );

    gfBlitBitmap( &screen, &bmp, 0, 0 );
    gfBlitBitmap( &screen, &bmp, 1280 - 320, 720 - 240 );

    gfLine( &screen, 0, 0, 1279, 719, gfColor( 255, 255, 0 ) );

    bspDCFlush();

    do{
        //gfBlitBitmap( &screen, &bmp, randomNumber() % ( 1280 - 320 ), randomNumber() % ( 720 - 240 ) );
        //bspDCFlush();

    }while( 1 );

    cleanup_platform();

    return 0;
}
